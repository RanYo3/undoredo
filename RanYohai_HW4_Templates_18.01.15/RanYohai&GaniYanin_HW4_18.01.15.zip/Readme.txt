Homework 4

Developed by:
	- Ran Yohai (201318854)
	- Gani Yanin (300434040)